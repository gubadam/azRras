# requires -Module ActiveDirectoryCSDsc
# requires -Module xAdcsDeployment

Configuration CreateRRAS
{
    param
    (
        [System.Management.Automation.PSCredential]$Admincreds
    )

    Import-DscResource -ModuleName ComputerManagementDsc #, PSDesiredStateConfiguration

    Node localhost
    {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        Script InstallRras {
            GetScript  = { @{} }
            TestScript = {
                $InstallState = Get-WindowsFeature DirectAccess-VPN | Select-Object -ExpandProperty InstallState
                If ($InstallState -ne 'Installed') { $false } else { $true }
            }
            SetScript  = {
                # Install the DirectAccess-VPN role; src: https://www.powershellgallery.com/packages/AOVPNTools/1.4.6/Content/Functions%5CInstall-VpnServer.ps1
                Write-Verbose 'Installing DirectAccess-VPN role...'
                Install-WindowsFeature -Name DirectAccess-VPN -IncludeManagementTools | Out-Null
            }
        }

        PendingReboot AfterInstallFeature {
            Name      = 'AfterInstallFeature'
            DependsOn = '[Script]InstallRras'
        }
        
        Script ConfigRras {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript  = {
                # Configure client-based VPN support
                Write-Verbose 'Configuring VPN services...'
                Install-RemoteAccess -VpnType VPN -Legacy | Out-Null

                # Enable inbox accounting
                Write-Verbose 'Enabling Remote Access inbox accounting...'
                Set-RemoteAccessAccounting -EnableAccountingType Inbox | Out-Null

                # Enable IKEv2 fragmentation support
                $Parameters = @{
                    Path         = 'HKLM:\SYSTEM\CurrentControlSet\Services\RemoteAccess\Parameters\Ikev2\'
                    Name         = 'EnableServerFragmentation'
                    PropertyType = 'DWORD'
                    Value        = '1'
                }

                Write-Verbose 'Enabling IKEv2 fragmentation support...'
                New-ItemProperty @Parameters -Force | Out-Null

                # Set IKEv2 VPN security baseline
                $Parameters = @{
                    AuthenticationTransformConstants    = 'GCMAES128'
                    CipherTransformConstants            = 'GCMAES128'
                    DHGroup                             = 'Group14'
                    EncryptionMethod                    = 'GCMAES128'
                    IntegrityCheckMethod                = 'SHA256'
                    PFSgroup                            = 'ECP256'
                    SALifeTimeSeconds                   = '28800'
                    MMSALifeTimeSeconds                 = '86400'
                    SADataSizeForRenegotiationKilobytes = '1024000'
                }

                Write-Verbose 'Setting IKEv2 VPN security baseline...'
                [PSCustomObject]$Parameters | Set-VpnServerConfiguration -CustomPolicy | Out-Null

                # Enforce CRL checking for device-based connections
                $Parameters = @{
                    Path         = 'HKLM:\SYSTEM\CurrentControlSet\Services\RemoteAccess\Parameters\Ikev2\'
                    Name         = 'CertAuthFlags'
                    PropertyType = 'DWORD'
                    Value        = '4'
                }

                Write-Verbose 'Enforce CRL check for device-based IKEv2 connections...'
                New-ItemProperty @Parameters -Force | Out-Null

                # Set authentication settings
                Write-Verbose 'Enabling EAP and machine certificate authentication...'
                Set-VpnAuthProtocol -UserAuthProtocolAccepted @('EAP', 'Certificate') | Out-Null

                Write-Verbose 'Restarting the RemoteAccess service...'
                Restart-Service -Name RemoteAccess -PassThru

                # Enable RADIUS authentication and accounting
                # Write-Verbose 'Enabling RADIUS authentication...'
                Invoke-Command -ScriptBlock { netsh.exe ras aaaa set authentication provider = radius }
                Invoke-Command -Scriptblock { netsh.exe ras aaaa set accounting provider = radius }

                # Disable IIS default document, delete default files, and disable default HTTP binding
                Write-Verbose 'Disabling IIS default document, deleting default files, and removing HTTP web binding... '
                Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter 'system.webServer/defaultDocument' -Name 'Enabled' -Value 'False'
                Remove-IISSiteBinding -Name 'Default Web Site' -BindingInformation '*:80:' -Confirm:$false
                Remove-Item -Path C:\Inetpub\wwwroot\iisstart.*
            }
            DependsOn  = '[PendingReboot]AfterInstallFeature'
        }

        PendingReboot AfterConfig {
            Name      = 'AfterConfig'
            DependsOn = '[Script]ConfigRras'
        }
    }
}