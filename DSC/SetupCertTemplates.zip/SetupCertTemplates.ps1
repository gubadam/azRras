# requires -Module ActiveDirectoryCSDsc
# requires -Module xAdcsDeployment

Configuration SetupCertTemplates
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$ArtifactsLocation
    )

    # Import-DscResource -ModuleName xAdcsDeployment #, PSDesiredStateConfiguration
    Import-Module ADCSTemplate

    Node localhost
    {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        Script CertTemplates {
            GetScript  = { @{} }
            TestScript = { 
                if (Get-ADCSTemplate -DisplayName "VPN User Authentication" && Get-ADCSTemplate -DisplayName "VPN Server Authentication") {
                    $true 
                } else {
                    $false
                }
            }
            SetScript  = {
                # '${artifactsLocation}/DSC/SetupCertTemplates.zip'
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                # 'https://github.com/gubadam/azRras/raw/testing/DSC/certTemplates/vpnServerAuthentication.json'
                Invoke-WebRequest -Uri "$using:ArtifactsLocation/DSC/certTemplates/vpnServerAuthentication.json" -UseBasicParsing -OutFile './vpnServerAuthentication.json'
                Invoke-WebRequest -Uri "$using:ArtifactsLocation/DSC/certTemplates/vpnUserAuthentication.json" -UseBasicParsing -OutFile './vpnUserAuthentication.json'

                New-ADCSTemplate -JSON (Get-Content ".\vpnUserAuthentication.json" -raw) -DisplayName "VPN User Authentication" -Identity "VPN Users" -AutoEnroll -Publish
                New-ADCSTemplate -JSON (Get-Content ".\vpnServerAuthentication.json" -raw) -DisplayName "VPN Server Authentication" -Identity "VPN Servers" -Autoenroll -Publish

                net stop "certsvc"
                net start "certsvc"
            }
            PsDscRunAsCredential = $Admincreds
            # DependsOn = '[PendingReboot]AfterConfig'
        }
    }
}