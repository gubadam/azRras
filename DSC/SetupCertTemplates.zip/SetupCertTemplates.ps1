# requires -Module ActiveDirectoryCSDsc
# requires -Module xAdcsDeployment

Configuration SetupCertTemplates
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$ArtifactsLocation
    )

    # Import-DscResource -ModuleName xAdcsDeployment #, PSDesiredStateConfiguration

    Node localhost
    {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        Script VpnAdGroups {
            GetScript  = { @{} }
            TestScript = { $false}
            SetScript  = {
                Invoke-WebRequest -Uri "$ArtifactsLocation/DSC/certTemplates/vpnServerAuthentication.json" -UseBasicParsing -OutFile './vpnServerAuthentication.json'
                Invoke-WebRequest -Uri "$ArtifactsLocation/DSC/certTemplates/vpnUserAuthentication.json" -UseBasicParsing -OutFile './vpnUserAuthentication.json'

                New-ADCSTemplate -JSON (Get-Content ".\vpnUserAuthentication.json" -raw) -DisplayName "VPN User Authentication" -Identity "VPN Users" -AutoEnroll -Publish
                New-ADCSTemplate -JSON (Get-Content ".\vpnServerAuthentication.json" -raw) -DisplayName "VPN Server Authentication" -Identity "VPN Servers" -Autoenroll -Publish

                net stop "certsvc"
                net start "certsvc"
            }
            # DependsOn = '[PendingReboot]AfterConfig'
        }
    }
}