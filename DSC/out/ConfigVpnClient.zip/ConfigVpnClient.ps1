Configuration ConfigVpnClient
{
    param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$AdcsVmHostname,

        [Parameter(Mandatory)]
        [String]$VpnFqdn,

        [Parameter(Mandatory)]
        [String]$RrasVmPublicIp,

        [String]$ArtifactsLocation
    )

    Node localhost
    {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        Script ImportRootCa {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                $rootCaCerts = get-childitem "\\$using:AdcsVmHostname\c$\Windows\System32\CertSrv\CertEnroll"
                $rootCaCerts | Where-Object {$_.name -like "*.crt"} | ForEach-Object {
                    Import-Certificate -FilePath $_.FullName -CertStoreLocation "Cert:\LocalMachine\Root"
                }
            }
            PsDscRunAsCredential = $Admincreds
            # DependsOn = '[xAdcsWebEnrollment]WebEnrollment', '[WindowsFeature]ADCSCA', '[xAdcsOnlineResponder]OnlineResponder'
        }
        
        Script RefreshKerberosTokens {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                gpupdate /force
                Start-Sleep -Seconds 1
                klist -li 0:0x3e7 purge
                Start-Sleep -Seconds 1
            }
            DependsOn = "[Script]ImportRootCa"
            # PsDscRunAsCredential = $Admincreds
        }

        Script SetupVpnCert {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                $cert = get-certificate -Template "VPNClientAuthentication" -CertStoreLocation "cert:\CurrentUser\My" #-SubjectName "CN=$using:VpnFqdn" -DnsName "$using:VpnFqdn","$env:computername" # -Url -Credential $Admincreds
                # Set-RemoteAccess -SslCertificate $cert.Certificate
                
                # Write-Verbose 'Restarting the RemoteAccess service...'
                # Restart-Service -Name RemoteAccess -PassThru
            }
            DependsOn = "[Script]RefreshKerberosTokens"
            PsDscRunAsCredential = $Admincreds
        }

        Script SetupDummyNameResolution {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                Add-Content -Path $env:windir\System32\drivers\etc\hosts -Value "`n$using:RrasVmPublicIp`t$using:VpnFqdn" -Force
            }
            DependsOn = "[Script]SetupVpnCert"
            PsDscRunAsCredential = $Admincreds
        }

        Script SetupVpnConnection {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                Invoke-WebRequest -Uri "$using:ArtifactsLocation/DSC/vpnConfig/eapConfig.xml" -UseBasicParsing -OutFile './eapConfig.xml'
                Add-VpnConnection -Name $using:VpnFqdn -ServerAddress $using:VpnFqdn -TunnelType Sstp -AuthenticationMethod Eap -EapConfigXmlStream (get-content '.\eapConfig.xml') -SplitTunneling
                rasdial $using:VpnFqdn
                # rasdial $VpnFqdn /disconnect
            }
            DependsOn = "[Script]SetupDummyNameResolution"
            PsDscRunAsCredential = $Admincreds
        }
    }
}

