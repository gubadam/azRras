# requires -Module ActiveDirectoryCSDsc
# requires -Module xAdcsDeployment

Configuration CreateNPS
{
    param
    (
        [System.Management.Automation.PSCredential]$Admincreds,
        [String]$RrasVmIp,
        [String]$ArtifactsLocation
    )

    Import-DscResource -ModuleName ComputerManagementDsc #, PSDesiredStateConfiguration

    Node localhost
    {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        Script InstallNps {
            GetScript  = { @{} }
            TestScript = {
                $InstallState = Get-WindowsFeature NPAS | Select-Object -ExpandProperty InstallState
                If ($InstallState -ne 'Installed') { $false } else { $true }
            }
            SetScript  = {
                # Install the Network Policy Server (NPS) role
                Write-Verbose 'Installing NPAS role...'
                Install-WindowsFeature NPAS -IncludeManagementTools | Out-Null

                # Enable auditing
                Write-Verbose 'Enabling auditing...'
                auditpol.exe /set /subcategory:"Network Policy Server" /success:enable /failure:enable | Out-Null

                # Install workaround for NPS issue on Windows Server 2019
                $OSVersion = (Get-CimInstance 'Win32_OperatingSystem').Version
                Write-Verbose "Server version is $OSVersion."

                if ($OSVersion -eq '10.0.17763') {
                    Write-Verbose 'Windows Server 2019 detected. Installing NPS workaround...'
                    sc.exe sidtype IAS unrestricted | Out-Null
                    # if ($Restart) {
                    #     Write-Verbose 'Restarting server...'
                    #     Start-Sleep -Seconds 3
                    #     Restart-Computer -Force
                    # } else {
                    #     Write-Warning 'The server must be restarted for these changes to take effect.'
                    # }
                }
            }
        }

        PendingReboot AfterConfig {
            Name      = 'AfterConfig'
            DependsOn = '[Script]InstallNps'
        }

        Script ImportNpsConfigTemplate {
            GetScript  = { @{} }
            TestScript = {
                $false
            }
            SetScript  = {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                Invoke-WebRequest -Uri "$using:ArtifactsLocation/DSC/npsConfig/npsConfig.xml" -UseBasicParsing -OutFile './npsConfig.xml'
                Import-NpsConfiguration -Path .\npsConfig.xml
            }
            DependsOn = '[PendingReboot]AfterConfig'
        }

        Script RegisterNpsInAd {
            GetScript  = { @{} }
            TestScript = {
                $false
            }
            SetScript  = {
                netsh nps add registeredserver
            }
            DependsOn = '[Script]ImportNpsConfigTemplate'
        }

        Script AddRadiusClient {
            GetScript  = { @{} }
            TestScript = {
                $false
            }
            SetScript  = {
                New-NpsRadiusClient -Name vpn -Address $RrasVmIp -SharedSecret ($Admincreds.password | ConvertFrom-SecureString -AsPlainText)
            }
            DependsOn = '[Script]RegisterNpsInAd'
        }
    }
}