Configuration ConfigRras
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$AdcsVmHostname,

        [Parameter(Mandatory)]
        [String]$VpnFqdn,

        [String]$NpsVmIp
    )

    # Import-DscResource -ModuleName xAdcsDeployment #, PSDesiredStateConfiguration

    Node localhost
    {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        Script ImportRootCa {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                $rootCaCerts = get-childitem "\\$using:AdcsVmHostname\c$\Windows\System32\CertSrv\CertEnroll"
                $rootCaCerts | Where-Object {$_.name -like "*.crt"} | ForEach-Object {
                    Import-Certificate -FilePath $_.FullName -CertStoreLocation "Cert:\LocalMachine\Root"
                }
            }
            PsDscRunAsCredential = $Admincreds
            # DependsOn = '[xAdcsWebEnrollment]WebEnrollment', '[WindowsFeature]ADCSCA', '[xAdcsOnlineResponder]OnlineResponder'
        }
        
        Script RefreshKerberosTokens {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                gpupdate /force
                Start-Sleep -Seconds 1
                klist -li 0:0x3e7 purge
                Start-Sleep -Seconds 1
            }
            DependsOn = "[Script]ImportRootCa"
            # PsDscRunAsCredential = $Admincreds
        }

        Script SetupVpnCert {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                $cert = get-certificate -Template "VPNServerAuthentication" -CertStoreLocation "cert:\LocalMachine\My" -SubjectName "CN=$using:VpnFqdn" -DnsName "$using:VpnFqdn","$env:computername" # -Url -Credential $Admincreds
                Set-RemoteAccess -SslCertificate $cert.Certificate
                
                Write-Verbose 'Restarting the RemoteAccess service...'
                Restart-Service -Name RemoteAccess -PassThru
            }
            DependsOn = "[Script]RefreshKerberosTokens"
            PsDscRunAsCredential = $Admincreds
        }

        Script SetupRadiusServer {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                # function ConvertFrom-SecureString-AsPlainText{
                #     [CmdletBinding()]
                #     param (
                #         [Parameter(
                #             Mandatory = $true,
                #             ValueFromPipeline = $true
                #         )]
                #         [System.Security.SecureString]
                #         $SecureString
                #     )
                #     $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
                #     $PlainTextString = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
                #     $PlainTextString
                # }
                Add-RemoteAccessRadius -ServerName $using:npsVmIp -SharedSecret $Admincreds.UserName -Purpose Authentication
                Set-VpnAuthProtocol -UserAuthProtocolAccepted MsChapv2,Certificate -TunnelAuthProtocolsAdvertised Certificates

                Write-Verbose 'Restarting the RemoteAccess service...'
                Restart-Service -Name RemoteAccess -PassThru
            }
            DependsOn = "[Script]SetupVpnCert"
            PsDscRunAsCredential = $Admincreds
        }
    }
}