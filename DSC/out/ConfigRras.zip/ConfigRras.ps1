Configuration ConfigRras
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$AdcsVmHostname,

        [Parameter(Mandatory)]
        [String]$VpnFqdn,

        [Parameter(Mandatory)]
        [String]$NpsVmIp
    )

    # Import-DscResource -ModuleName xAdcsDeployment #, PSDesiredStateConfiguration

    Node localhost
    {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        Script ImportRootCa {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                $rootCaCerts = get-childitem "\\$using:AdcsVmHostname\c$\Windows\System32\CertSrv\CertEnroll"
                $rootCaCerts | Where-Object {$_.name -like "*.crt"} | ForEach-Object {
                    Import-Certificate -FilePath $_.FullName -CertStoreLocation "Cert:\LocalMachine\Root"
                }
            }
            PsDscRunAsCredential = $Admincreds
            # DependsOn = '[xAdcsWebEnrollment]WebEnrollment', '[WindowsFeature]ADCSCA', '[xAdcsOnlineResponder]OnlineResponder'
        }
        
        Script RefreshKerberosTokens {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                gpupdate /force
                Start-Sleep -Seconds 1
                klist -li 0:0x3e7 purge
                Start-Sleep -Seconds 1
            }
            DependsOn = "[Script]ImportRootCa"
            # PsDscRunAsCredential = $Admincreds
        }

        Script SetupVpnCert {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                $cert = get-certificate -Template "VPNServerAuthentication" -CertStoreLocation "cert:\LocalMachine\My" -SubjectName "CN=$using:VpnFqdn" -DnsName "$using:VpnFqdn","$env:computername" # -Url -Credential $Admincreds
                Set-RemoteAccess -SslCertificate $cert.Certificate
                
                Write-Verbose 'Restarting the RemoteAccess service...'
                Restart-Service -Name RemoteAccess -PassThru
            }
            DependsOn = "[Script]RefreshKerberosTokens"
            PsDscRunAsCredential = $Admincreds
        }

        Script SetupRadiusServer {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                # TODO: Exception calling "Deserialize" with "1" argument(s): "Key not valid for use in specified state." - https://support.oneidentity.com/kb/4209271/error-key-not-valid-for-use-in-specified-state-when-trying-to-log-in-to-the-application-server
                # Add-RemoteAccessRadius -ServerName "$($using:npsVmIp)" -SharedSecret $using:Admincreds.UserName -Purpose Authentication
                Add-RemoteAccessRadius -ServerName "$($using:npsVmIp)" -SharedSecret 'npsSecret' -Purpose Authentication

                Set-VpnAuthProtocol -UserAuthProtocolAccepted MsChapv2,Certificate -TunnelAuthProtocolsAdvertised Certificates

                Write-Verbose 'Restarting the RemoteAccess service...'
                Restart-Service -Name RemoteAccess -PassThru
            }
            DependsOn = "[Script]SetupVpnCert"
            PsDscRunAsCredential = $Admincreds
        }

        Script SetupIpAddressRange {
            GetScript  = { @{} }
            TestScript = { $false }
            SetScript = {
                Add-VpnIPAddressRange -IPAddressRange "172.0.0.2","172.20.0.200"
            }
            DependsOn = "[Script]SetupRadiusServer"
            PsDscRunAsCredential = $Admincreds
        }
    }
}