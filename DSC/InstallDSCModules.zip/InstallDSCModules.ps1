Configuration InstallDSCModules {

    $env:PSModulePath += ";$PSScriptRoot"

    Import-DscResource -ModuleName PowerShellModule
    PSModuleResource xActiveDirectory {
        Ensure = 'present'
        Module_Name = 'xActiveDirectory'
    }

    Import-DscResource -ModuleName PowerShellModule
    PSModuleResource xNetworking {
        Ensure = 'present'
        Module_Name = 'xNetworking'
    }
}