# [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Configuration InstallDSCModules {

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    # try {
    #     If ( (Get-PackageProvider -Name Nuget -ListAvailable -ErrorAction Stop ).Version -le 2.8.5.208 ) {
    #         Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
    #     }
    # } catch {
    #     Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
    # }

    # Register-PSRepository -Default

    # if ( (Get-PSRepository -Name 'PSGallery').InstallationPolicy -eq 'Untrusted' ) {
    #     Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
    # }

    # Get-PSRepository | fl *

    $env:PSModulePath += ";$PSScriptRoot"

    Import-DscResource -ModuleName PowerShellModule

    Script ConfigureScriptRepository
        {
            SetScript = {
                try {
                    If ( (Get-PackageProvider -Name Nuget -ListAvailable -ErrorAction Stop ).Version -le 2.8.5.208 ) {
                        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
                    }
                } catch {
                    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
                }
            
                # Register-PSRepository -Default

                Register-PSRepository -Name PSGallery -SourceLocation 'https://www.powershellgallery.com/api/v2/items/psscript'
            
                if ( (Get-PSRepository -Name 'PSGallery').InstallationPolicy -eq 'Untrusted' ) {
                    Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
                }
            }
            TestScript = { 
                if (((Get-PSRepository -Name PSGallery).InstallationPolicy -eq 'Trusted') -and ((Get-PackageProvider -Name Nuget -ListAvailable -ErrorAction Stop).Version -ge 2.8.5.208)) {
                    $true
                } else {
                    $false
                }
            }
            GetScript = { @{ Result = "" + ((Get-PSRepository -Name PSGallery) + " | " + (Get-PackageProvider -Name Nuget -ListAvailable -ErrorAction Stop)) } }
        }

    # PSModuleRepositoryResource PSGallery
    # {
    #     Ensure = 'present'
    #     Name = 'PSGallery'
    #     PublishLocation = 'http://www.somelocation/publish'
    #     SourceLocation = 'https://www.powershellgallery.com/api/v2/items/psscript'
    # }

    PSModuleResource xActiveDirectory
    {
        Ensure = 'present'
        Module_Name = 'xActiveDirectory'
        Repository = 'PSGallery'
        DependsOn = @('[Script]ConfigureScriptRepository')
    }

    PSModuleResource xNetworking
    {
        Ensure = 'present'
        Module_Name = 'xNetworking'
        Repository = 'PSGallery'
        DependsOn = @('[Script]ConfigureScriptRepository')   
    }
}

# //
# Import-Module -Name PowerShellGet -Force
# Import-Module -Name PackageManagement -Force

# try {
#     If ( (Get-PackageProvider -Name Nuget -ListAvailable -ErrorAction Stop ).Version -le 2.8.5.208 ) {
#         Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
#     }
# catch {
#     Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
# }

# if ( (Get-PSRepository -Name 'PSGallery').InstallationPolicy -eq 'Untrusted' ) {
#     Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
# }

# if ( -not ( Get-Module -Name PSDscResources -ListAvailable ) ) {
#     Install-Module PSDscResources -AllowClobber -SkipPublisherCheck -Confirm:$false -Force
# }

# if ( -not ( Get-Module -Name PSDscResources ) ) {
#     Import-Module -Name PSDscResources -Global -Force -PassThru
# }
