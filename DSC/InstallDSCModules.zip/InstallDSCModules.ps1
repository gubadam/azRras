[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Configuration InstallDSCModules {

    if ((Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue).Version -lt '2.8.5.201') {
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Confirm:$false
    }

    $env:PSModulePath += ";$PSScriptRoot"

    Import-DscResource -ModuleName PowerShellModule

    PSModuleResource xActiveDirectory {
        Ensure = 'present'
        Module_Name = 'xActiveDirectory'
    }

    PSModuleResource xNetworking {
        Ensure = 'present'
        Module_Name = 'xNetworking'
    }
}