Configuration InstallDSCModules {

    $env:PSModulePath += ";$PSScriptRoot"

    Import-DscResource -ModuleName PowerShellModule
    PSModuleResource xActiveDirectory {
        Ensure = 'present'
        Module_Name = 'xActiveDirectory'
    }
}