Configuration InstallDSCModules {

    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force

    $env:PSModulePath += ";$PSScriptRoot"

    Import-DscResource -ModuleName PowerShellModule
    
    PSModuleResource xActiveDirectory {
        Ensure = 'present'
        Module_Name = 'xActiveDirectory'
    }

    PSModuleResource xNetworking {
        Ensure = 'present'
        Module_Name = 'xNetworking'
    }
}