[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Configuration InstallDSCModules {

    try {
        If ( (Get-PackageProvider -Name Nuget -ListAvailable -ErrorAction Stop ).Version -le 2.8.5.208 ) {
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
        }
    } catch {
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
    }

    if ( (Get-PSRepository -Name 'PSGallery').InstallationPolicy -eq 'Untrusted' ) {
        Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
    }

    $env:PSModulePath += ";$PSScriptRoot"

    Import-DscResource -ModuleName PowerShellModule

    PSModuleResource xActiveDirectory {
        Ensure = 'present'
        Module_Name = 'xActiveDirectory'
    }

    PSModuleResource xNetworking {
        Ensure = 'present'
        Module_Name = 'xNetworking'
    }
}

# //
# Import-Module -Name PowerShellGet -Force
# Import-Module -Name PackageManagement -Force

# try {
#     If ( (Get-PackageProvider -Name Nuget -ListAvailable -ErrorAction Stop ).Version -le 2.8.5.208 ) {
#         Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
#     }
# catch {
#     Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force
# }

# if ( (Get-PSRepository -Name 'PSGallery').InstallationPolicy -eq 'Untrusted' ) {
#     Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
# }

# if ( -not ( Get-Module -Name PSDscResources -ListAvailable ) ) {
#     Install-Module PSDscResources -AllowClobber -SkipPublisherCheck -Confirm:$false -Force
# }

# if ( -not ( Get-Module -Name PSDscResources ) ) {
#     Import-Module -Name PSDscResources -Global -Force -PassThru
# }
